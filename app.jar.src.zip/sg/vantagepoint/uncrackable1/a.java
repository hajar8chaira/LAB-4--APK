package sg.vantagepoint.uncrackable1;

import android.util.Base64;
import android.util.Log;

public class a {
  public static boolean a(String paramString) {
    byte[] arrayOfByte = Base64.decode("5UJiFctbmgbDoLXmpL12mkno8HT4Lv8dlat8FxR2GOc=", 0);
    try {
      arrayOfByte = sg.vantagepoint.a.a.a(b("8d127684cbc37c17616d806cf50473cc"), arrayOfByte);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AES error:");
      stringBuilder.append(exception.getMessage());
      Log.d("CodeCheck", stringBuilder.toString());
      arrayOfByte = new byte[0];
    } 
    return paramString.equals(new String(arrayOfByte));
  }
  
  public static byte[] b(String paramString) {
    int i = paramString.length();
    byte[] arrayOfByte = new byte[i / 2];
    for (byte b = 0; b < i; b += 2)
      arrayOfByte[b / 2] = (byte)((Character.digit(paramString.charAt(b), 16) << 4) + Character.digit(paramString.charAt(b + 1), 16)); 
    return arrayOfByte;
  }
}


/* Location:              C:\APK-Analysis\app.jar!\sg\vantagepoin\\uncrackable1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */