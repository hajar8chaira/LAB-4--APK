package sg.vantagepoint.uncrackable1;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import sg.vantagepoint.a.b;
import sg.vantagepoint.a.c;

public class MainActivity extends Activity {
  private void a(String paramString) {
    AlertDialog alertDialog = (new AlertDialog.Builder((Context)this)).create();
    alertDialog.setTitle(paramString);
    alertDialog.setMessage("This is unacceptable. The app is now going to exit.");
    alertDialog.setButton(-3, "OK", new DialogInterface.OnClickListener(this) {
          final MainActivity a;
          
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            System.exit(0);
          }
        });
    alertDialog.setCancelable(false);
    alertDialog.show();
  }
  
  protected void onCreate(Bundle paramBundle) {
    if (c.a() || c.b() || c.c())
      a("Root detected!"); 
    if (b.a(getApplicationContext()))
      a("App is debuggable!"); 
    super.onCreate(paramBundle);
    setContentView(2130903040);
  }
  
  public void verify(View paramView) {
    String str = ((EditText)findViewById(2130837505)).getText().toString();
    AlertDialog alertDialog = (new AlertDialog.Builder((Context)this)).create();
    if (a.a(str)) {
      alertDialog.setTitle("Success!");
      str = "This is the correct secret.";
    } else {
      alertDialog.setTitle("Nope...");
      str = "That's not it. Try again.";
    } 
    alertDialog.setMessage(str);
    alertDialog.setButton(-3, "OK", new DialogInterface.OnClickListener(this) {
          final MainActivity a;
          
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            param1DialogInterface.dismiss();
          }
        });
    alertDialog.show();
  }
}


/* Location:              C:\APK-Analysis\app.jar!\sg\vantagepoin\\uncrackable1\MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */