package sg.vantagepoint.a;

import android.content.Context;

public class b {
  public static boolean a(Context paramContext) {
    return (((paramContext.getApplicationContext().getApplicationInfo()).flags & 0x2) != 0);
  }
}


/* Location:              C:\APK-Analysis\app.jar!\sg\vantagepoint\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */