package sg.vantagepoint.a;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class a {
  public static byte[] a(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "AES/ECB/PKCS7Padding");
    Cipher cipher = Cipher.getInstance("AES");
    cipher.init(2, secretKeySpec);
    return cipher.doFinal(paramArrayOfbyte2);
  }
}


/* Location:              C:\APK-Analysis\app.jar!\sg\vantagepoint\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */